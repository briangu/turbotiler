package org.linkedin.contest.game.api;

/**
 * A marker interface for possible moves by a player
 */
public interface Move
{

}
